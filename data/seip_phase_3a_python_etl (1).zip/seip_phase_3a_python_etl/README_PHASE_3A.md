# SEIP Phase 3A — Python ETL Extractor and Validator

This phase implements the first Python ETL layer for SEIP.

## What it does

1. Reads CSV/XLSX survey files from `data/raw`
2. Normalises column names
3. Validates job seeker records
4. Splits records into accepted and rejected outputs
5. Writes structured JSON logs

## Setup

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```

## Run

Place your job seeker CSV/XLSX file in:

```text
data/raw/
```

Then run:

```bash
python run_phase_3a_job_seeker_etl.py
```

## Outputs

Accepted records:

```text
data/processed/
```

Rejected records:

```text
data/rejected/
```

Logs:

```text
logs/
```

## Validation rules included

- Consent must be true
- Age must be between 14 and 80
- Township must be in SEIP target township list
- SA ID must be 13 numeric digits
- NQF level must be between 1 and 10
- GPS must fall inside approximate Gauteng bounding box
