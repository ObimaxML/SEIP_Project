from src.config.settings import (
    RAW_DATA_DIR,
    PROCESSED_DATA_DIR,
    REJECTED_DATA_DIR,
    LOG_DIR,
    SUPPORTED_EXTENSIONS,
    JOB_SEEKER_REQUIRED_COLUMNS,
    VALID_TOWNSHIPS,
)
from src.extractors.excel_extractor import SurveyExtractor
from src.validators.survey_validator import JobSeekerValidator
from src.utils.logger import setup_logger, log_event
from datetime import datetime

def main():
    logger = setup_logger(LOG_DIR)

    log_event(logger, "PHASE_3A_START", raw_data_dir=str(RAW_DATA_DIR))

    extractor = SurveyExtractor(SUPPORTED_EXTENSIONS)
    df = extractor.read_directory(RAW_DATA_DIR)

    if df.empty:
        log_event(logger, "NO_INPUT_FILES_FOUND")
        print(f"No CSV/XLSX files found in {RAW_DATA_DIR}")
        return

    log_event(logger, "EXTRACT_COMPLETE", records=len(df), columns=list(df.columns))

    validator = JobSeekerValidator(
        required_columns=JOB_SEEKER_REQUIRED_COLUMNS,
        valid_townships=VALID_TOWNSHIPS
    )

    accepted, rejected = validator.validate(df)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    accepted_path = PROCESSED_DATA_DIR / f"job_seekers_accepted_{timestamp}.csv"
    rejected_path = REJECTED_DATA_DIR / f"job_seekers_rejected_{timestamp}.csv"

    accepted.to_csv(accepted_path, index=False)
    rejected.to_csv(rejected_path, index=False)

    log_event(
        logger,
        "VALIDATION_COMPLETE",
        records_received=len(df),
        records_accepted=len(accepted),
        records_rejected=len(rejected),
        accepted_path=str(accepted_path),
        rejected_path=str(rejected_path)
    )

    print("Phase 3A ETL completed.")
    print(f"Accepted records: {len(accepted)}")
    print(f"Rejected records: {len(rejected)}")
    print(f"Accepted file: {accepted_path}")
    print(f"Rejected file: {rejected_path}")

if __name__ == "__main__":
    main()
