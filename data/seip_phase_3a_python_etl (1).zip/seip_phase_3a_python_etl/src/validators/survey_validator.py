import pandas as pd
from datetime import date

class JobSeekerValidator:
    def __init__(self, required_columns, valid_townships):
        self.required_columns = required_columns
        self.valid_townships = valid_townships

    def validate_required_columns(self, df: pd.DataFrame):
        missing = [col for col in self.required_columns if col not in df.columns]
        if missing:
            raise ValueError(f"Missing required columns: {missing}")

    def parse_bool(self, value):
        if isinstance(value, bool):
            return value
        if pd.isna(value):
            return False
        return str(value).strip().lower() in ["true", "yes", "y", "1"]

    def calculate_age(self, dob):
        if pd.isna(dob):
            return None
        dob = pd.to_datetime(dob, errors="coerce")
        if pd.isna(dob):
            return None
        today = pd.Timestamp(date.today())
        return today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))

    def is_valid_sa_id_basic(self, value):
        if pd.isna(value):
            return False
        value = str(value).strip()
        return value.isdigit() and len(value) == 13

    def validate_row(self, row):
        errors = []

        if not self.parse_bool(row.get("consent_given")):
            errors.append("CONSENT_REQUIRED")

        age = self.calculate_age(row.get("date_of_birth"))
        if age is None or age < 14 or age > 80:
            errors.append("AGE_RANGE_VALID")

        township = str(row.get("township", "")).strip().upper()
        if township not in self.valid_townships:
            errors.append("TOWNSHIP_VALID")

        if not self.is_valid_sa_id_basic(row.get("id_number")):
            errors.append("SA_ID_BASIC_FORMAT_VALID")

        nqf = row.get("nqf_level")
        if pd.notna(nqf):
            try:
                nqf = int(nqf)
                if nqf < 1 or nqf > 10:
                    errors.append("NQF_LEVEL_VALID")
            except Exception:
                errors.append("NQF_LEVEL_VALID")

        lat = row.get("gps_latitude")
        lon = row.get("gps_longitude")
        if pd.notna(lat) and pd.notna(lon):
            try:
                lat = float(lat)
                lon = float(lon)
                if not (-27.5 <= lat <= -25.0 and 27.0 <= lon <= 29.5):
                    errors.append("GPS_IN_GAUTENG")
            except Exception:
                errors.append("GPS_IN_GAUTENG")

        return errors

    def validate(self, df: pd.DataFrame):
        self.validate_required_columns(df)

        df = df.copy()
        df["validation_errors"] = df.apply(self.validate_row, axis=1)
        df["validation_status"] = df["validation_errors"].apply(
            lambda errors: "VALID" if len(errors) == 0 else "REJECTED"
        )

        accepted = df[df["validation_status"] == "VALID"].copy()
        rejected = df[df["validation_status"] == "REJECTED"].copy()

        return accepted, rejected
