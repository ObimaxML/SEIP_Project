from pathlib import Path
import pandas as pd
from typing import List

class SurveyExtractor:
    def __init__(self, supported_extensions: List[str]):
        self.supported_extensions = supported_extensions

    def normalise_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        df.columns = (
            df.columns
            .str.strip()
            .str.lower()
            .str.replace(" ", "_", regex=False)
            .str.replace("-", "_", regex=False)
        )
        return df

    def read_file(self, file_path: Path) -> pd.DataFrame:
        suffix = file_path.suffix.lower()

        if suffix == ".csv":
            df = pd.read_csv(file_path)
        elif suffix == ".xlsx":
            df = pd.read_excel(file_path)
        else:
            raise ValueError(f"Unsupported file type: {suffix}")

        df = self.normalise_columns(df)
        df["source_file_name"] = file_path.name
        return df

    def read_directory(self, directory: Path) -> pd.DataFrame:
        frames = []

        for file_path in directory.iterdir():
            if file_path.suffix.lower() in self.supported_extensions:
                frames.append(self.read_file(file_path))

        if not frames:
            return pd.DataFrame()

        return pd.concat(frames, ignore_index=True)
