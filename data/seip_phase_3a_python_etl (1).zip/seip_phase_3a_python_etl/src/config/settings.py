from pathlib import Path
from dotenv import load_dotenv
import os

load_dotenv()

PROJECT_ROOT = Path(__file__).resolve().parents[2]

RAW_DATA_DIR = PROJECT_ROOT / os.getenv("RAW_DATA_DIR", "data/raw")
PROCESSED_DATA_DIR = PROJECT_ROOT / os.getenv("PROCESSED_DATA_DIR", "data/processed")
REJECTED_DATA_DIR = PROJECT_ROOT / os.getenv("REJECTED_DATA_DIR", "data/rejected")
LOG_DIR = PROJECT_ROOT / os.getenv("LOG_DIR", "logs")

for path in [RAW_DATA_DIR, PROCESSED_DATA_DIR, REJECTED_DATA_DIR, LOG_DIR]:
    path.mkdir(parents=True, exist_ok=True)

SUPPORTED_EXTENSIONS = [".csv", ".xlsx"]

JOB_SEEKER_REQUIRED_COLUMNS = [
    "respondent_id",
    "consent_given",
    "first_name",
    "last_name",
    "id_number",
    "date_of_birth",
    "gender",
    "township",
    "survey_date"
]

VALID_TOWNSHIPS = {
    "SOWETO",
    "DIEPSLOOT",
    "ALEXANDRA",
    "ORANGE_FARM",
    "TEMBISA",
    "KATLEHONG",
    "VOSLOORUS",
    "KAGISO",
    "PROTEA_GLEN"
}
